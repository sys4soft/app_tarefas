
let id_uuser = null;

window.onload = () => {
    
    // get id_user
    const url = new URL(window.location.href);
    id_user = url.searchParams.get('id_user');
    console.log(id_user);

}